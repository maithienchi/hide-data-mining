- Ý Tưởng: bên trong file PDF có các MediaBox có thể dùng để nhúng dữ liệu
+ Bên trong MediaBox[X1 X2 X3 X4] có 4 con số, vd X1 = 1 thì minh có thể thay thế nó bằng 1.0055, điều này sẽ k làm ảnh hưởng nhìu đến file PDF
+ 1.0055 trong đó 55 là 1 con số ám chỉ 1 ký tự nào đó (có thể là mã ascii hoặc 1 bảng mã tự định nghĩa)
+ thay vì biến 1 thành 1.0055 ta có thể biến nó thành 1.00553233... với mỗi số 55, 32, 33,... sẽ dại diện cho 1 ký tự => tăng sức chứa
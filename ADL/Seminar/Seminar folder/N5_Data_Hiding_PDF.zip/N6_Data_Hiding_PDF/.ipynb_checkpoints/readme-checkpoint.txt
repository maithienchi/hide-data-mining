- Ý Tưởng: bên trong file PDF có các MediaBox có thể dùng để nhúng dữ liệu
+ Bên trong MediaBox[X1 X2 X3 X4] có 4 con số, vd X1 = 1 thì minh có thể thay thế nó bằng 1.0055, điều này sẽ k làm ảnh hưởng nhìu đến file PDF
+ 1.0055 trong đó 55 là 1 con số ám chỉ 1 ký tự nào đó (có thể là mã ascii hoặc 1 bảng mã tự định nghĩa)
+ thay vì biến 1 thành 1.0055 ta có thể biến nó thành 1.005500320033... với mỗi số 55, 32, 33,... sẽ dại diện cho 1 ký tự => tăng sức chứa

- Code trong file Demo.ipynb theo hướng dẫn bên dưới (chú ý cách xuất hiện của từ khóa "MediaBox" trong file pdf)

- Hàm Embed_Mgs(msg_file, pdf_file, mapping_table, marked_number, stego_pdf):
B1: đọc message từ file lên và dùng hàm Mapping_Value để chuyển các ký tự thành số và bỏ vào mảng msg_digits
B2: đọc file pdf_file lên, bỏ nội dung file vào biến pdf_content
B3: digit_per_num = msg_digits.length/(pdf_content.count("MediaBox")*4) (làm tròn lên, vd: 1.1 => 2)
B4: is_stop = false
B5: foreach chỗ có từ khóa "MediaBox"
	1. lấy ra 4 số trong cặp dấu '[...]'
	2. với mỗi số n:
		2.1 for i từ 0 cho tới digit_per_num
			2.1.1 if n là int và i==0 thì n += '.' + marked_number + msg_digits[j]
				  else thì n += marked_number + msg_digits[j]
			2.1.2 j++
			2.1.3 kiểm tra nếu j >= msg_digits.length thì is_stop = true và break khỏi for '2.1'
		2.2 nghi lại số n mới vào pdf_content
		2.3 nếu is_stop == true thì break khỏi for '2.'
	3. nếu is_stop == true thì break khỏi for 'B5'
B6: Ghi stego_pdf với nội dung pdf_content vừa biến đổi

- Hàm Extract_Msg(stego_pdf, mapping_table, marked_number, extr_msg):
B1: đọc file stego_pdf, bỏ nội dung vào biến pdf_content
B2: msg = ''
B3: is_stop = false
B4: foreach chỗ có từ khóa "MediaBox"
	1. lấy ra 4 số trong cặp dấu '[...]'
	2. với mỗi số n:
		2.1 temp = split(marked_number)
		2.2 if temp.length > 1 thì for từ i = 1 đến hết mảng temp
				2.2.1 msg += Mapping_Value(mapping_table, temp[i])
			else thì is_stop = true
		2.3 nếu is_stop == true thì break khỏi for '2.'
	3. nếu is_stop == true thì break khỏi for 'B4'
B5: Ghi msg xuống file extr_msg